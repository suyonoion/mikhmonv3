## Changelog

### Update 11-01-2018 V3.4 MikhmonGreen oleh suyonoion
1. Perubahan tampilan dashboard. Traffic TX/RX lingkaran dan Hotspot Log berwarna
2. Perubahan warna ui dengan tema green transparan.
3. Perubahan tampilan hotspot log dan tabel form.

### Update 10-30-2018 V3.4
1. Penambahan cek spasi di nama user profile.
2. Penambahan user profile dan comment di Report. Yang perlu dilakukan adalah update user profile dari Mikhmon, buka user profile yang ingin diupdate kemudian klik Save. 
3. Penambahan filter berdasarkan server hotspot di Hotspot Active.


### Update 10-24-2018 V3.3
1. Perubahan struktur menu.
2. Penambahan Hotspot Cookie dan System Scheduler.
3. Perubahan Generate User. Menghilangkan huruf l,L,q,Q,o,O serta angka 1 dan 0.
4. Perbaikan remove user.

### Update 09-10-2018 V3.2
1. Penambahan kolom Time Left di Hotspot Active.
2. Penambahan Parent Queue di Add dan Edit User Profile (Bagaimana cara penggunaannya? silakan pelajari Simple Queue Mikrotik).
3. Penyesuaian format Data Limit user menjadi Byte Binary ([base 2](https://www.gbmb.org/gigabytes)).
4. Reformat Uptime.
